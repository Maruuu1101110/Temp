import 'package:flutter/material.dart';
import '../screens/23_activity3_signin.dart';
import '../widgets/01_textfields.dart';
import '../widgets/02_buttons.dart';
import '../widgets/03_image.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController _firstName = TextEditingController();
  final TextEditingController _lastName = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _courseYearController = TextEditingController();
  final TextEditingController _departmentController = TextEditingController();
  final TextEditingController _collegeController = TextEditingController();

  void navigateToPage(Widget page) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }

  void clearAllFields() {
    _firstName.clear();
    _lastName.clear();
    _emailController.clear();
    _courseYearController.clear();
    _departmentController.clear();
    _collegeController.clear();
  }

  Widget _buildInputFields() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: CustomTextfield(
                controller: _firstName,
                label: "First Name",
                hintText: "Juan",
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: CustomTextfield(
                controller: _lastName,
                label: "Last Name",
                hintText: "Dela Cruz",
              ),
            ),
          ],
        ),
        SizedBox(height: 10),
        CustomTextfield(
          controller: _emailController,
          label: "Email Address",
          hintText: "email@sample.com",
          prefixWidget: Icon(Icons.email_outlined),
        ),
        SizedBox(height: 10),

        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Expanded(
              child: CustomTextfield(
                controller: _courseYearController,
                label: "Course & Year",
                hintText: "BSCS - 1",
                prefixWidget: Icon(Icons.book_outlined),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: CustomTextfield(
                controller: _collegeController,
                label: "College",
                prefixWidget: Icon(Icons.school_outlined),
              ),
            ),
          ],
        ),
        SizedBox(height: 10),
        CustomTextfield(
          controller: _departmentController,
          label: "Department",
          prefixWidget: Icon(Icons.group_outlined),
        ),

        SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            CustomButtons(
              text: "Clear",
              buttonColor: Colors.white,
              onPressed: () => clearAllFields(),
            ),
            SizedBox(width: 10),
            CustomButtons(
              text: "Create",
              buttonColor: Colors.blue,
              onPressed: () => navigateToPage(SignInScreen()),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Theme(
        data: ThemeData(fontFamily: 'sans-serif'),
        child: Center(
          child: Container(
            width: (screenWidth * 0.8).clamp(400, 450),
            height: 650,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              boxShadow: [BoxShadow(blurRadius: 8, color: Colors.black)],
              color: Colors.white,
              border: null,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                CustomImageWidget(
                  imagePath: "assets/sign_in.png",
                  imageWidth: screenWidth,
                  imageHeight: 200,
                ),
                Text(
                  "Create your account",
                  style: TextStyle(
                    fontSize: 30,
                    fontFamily: 'sans-serif',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Divider(thickness: 1, color: Colors.black26),
                _buildInputFields(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
