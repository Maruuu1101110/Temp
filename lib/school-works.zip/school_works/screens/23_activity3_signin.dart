import 'package:flutter/material.dart';
import '../screens/23_activity3_registration.dart';
import '../widgets/01_textfields.dart';
import '../widgets/02_buttons.dart';
import '../widgets/03_image.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final TextEditingController _userController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  bool isObs = true;

  void navigateToPage(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => page));
  }

  Widget _buildFieldIndicator(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          text,
          style: TextStyle(
            color: Colors.blue,
            fontSize: 16,
            fontFamily: 'monospace',
          ),
        ),
      ),
    );
  }

  Widget _buildInputFields(bool checkForInput) {
    return Column(
      children: [
        _buildFieldIndicator("user"),
        CustomTextfield(
          controller: _userController,
          hintText: "user123",
          label: "Enter your username",
          suffixWidget: Icon(Icons.person_outlined),
          onChanged: (value) => setState(() {}),
        ),
        SizedBox(height: 10),
        _buildFieldIndicator("password"),
        CustomTextfield(
          isObscure: isObs,
          hintText: isObs ? "********".toUpperCase() : "password",
          controller: _passController,
          label: "Enter your password",
          suffixWidget: IconButton(
            tooltip: isObs ? "Show Password" : "Hide Password",
            onPressed: () => setState(() {
              isObs = !isObs;
            }),
            icon: isObs
                ? Icon(Icons.remove_red_eye_outlined)
                : Icon(Icons.remove_red_eye),
          ),
          onChanged: (value) => setState(() {}),
        ),
        SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            CustomButtons(
              text: "Clear",
              buttonColor: Colors.white,
              onPressed: () {
                setState(() {
                  _userController.clear();
                  _passController.clear();
                });
              },
            ),
            SizedBox(width: 10),
            AnimatedSwitcher(
              duration: Duration(milliseconds: 100),
              child: CustomButtons(
                key: ValueKey(checkForInput),
                text: "Submit",
                buttonColor: !checkForInput
                    ? const Color.fromARGB(255, 212, 212, 212)
                    : Colors.blue,
                onPressed: !checkForInput
                    ? null
                    : () => navigateToPage(RegistrationScreen()),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final parentWidth = MediaQuery.of(context).size.width;
    final checkForInput =
        _userController.text.isNotEmpty && _passController.text.isNotEmpty;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Theme(
        data: ThemeData(fontFamily: 'sans-serif'),
        child: Center(
          child: Container(
            width: (parentWidth * 0.8).clamp(400, 400),
            height: 500,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              boxShadow: [BoxShadow(blurRadius: 8, color: Colors.black)],
              color: Colors.white,
              border: null,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                CustomImageWidget(
                  imagePath: "assets/welcome_cats.png",
                  imageWidth: parentWidth,
                  imageHeight: 150,
                ),
                Text(
                  "Sign in to your account",
                  style: TextStyle(
                    fontSize: 25,
                    fontFamily: 'sans-serif',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Divider(thickness: 1, color: Colors.black26),
                _buildInputFields(checkForInput),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
