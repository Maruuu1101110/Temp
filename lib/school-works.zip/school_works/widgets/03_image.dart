import 'package:flutter/material.dart';

class CustomImageWidget extends StatelessWidget {
  final String imagePath;
  final double imageWidth;
  final double imageHeight;
  const CustomImageWidget({
    super.key,
    required this.imagePath,
    required this.imageWidth,
    required this.imageHeight,
  });

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      imagePath,
      errorBuilder: (context, error, stackTrace) {
        return Column(
          children: [
            Icon(
              Icons.image_not_supported_outlined,
              size: imageWidth < imageHeight ? imageWidth : imageHeight,
            ),
            Text("Image not found"),
          ],
        );
      },
      width: imageWidth,
      height: imageHeight,
    );
  }
}
