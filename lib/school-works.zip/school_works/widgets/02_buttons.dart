import 'package:flutter/material.dart';

class CustomButtons extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final Color buttonColor;
  final Color foregroundColor = Colors.black87;
  const CustomButtons({
    super.key,
    required this.text,
    this.onPressed,
    required this.buttonColor,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ButtonStyle(
        shadowColor: WidgetStatePropertyAll(Colors.black),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.black54, width: 0.5),
          ),
        ),
        backgroundColor: WidgetStatePropertyAll(buttonColor),
        foregroundColor: WidgetStatePropertyAll(foregroundColor),
      ),
      onPressed: onPressed,
      child: Text(text),
    );
  }
}
