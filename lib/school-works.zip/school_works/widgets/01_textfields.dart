import 'package:flutter/material.dart';

class CustomTextfield extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hintText;
  final Widget? suffixWidget;
  final Widget? prefixWidget;
  final bool? isObscure;
  final ValueChanged? onChanged;

  const CustomTextfield({
    super.key,
    required this.controller,
    required this.label,
    this.hintText,
    this.prefixWidget,
    this.suffixWidget,
    this.onChanged,
    this.isObscure,
  });

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        textSelectionTheme: TextSelectionThemeData(
          cursorColor: Colors.black54,
          selectionColor: Colors.black12,
          selectionHandleColor: Colors.black26,
        ),
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        obscureText: isObscure ?? false,
        decoration: InputDecoration(
          label: Text(label),
          hintText: hintText,
          hintStyle: TextStyle(color: Colors.black38, fontFamily: 'monospace'),
          suffixIcon: suffixWidget,
          prefixIcon: prefixWidget,
          floatingLabelBehavior: FloatingLabelBehavior.never,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Color.fromRGBO(20, 51, 214, 0.8),
              width: 2,
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blue),
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}
